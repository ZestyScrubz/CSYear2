#ifndef SNACKAROO
#define SNACKAROO

// function prototypes
void header();
void printHelp();
void dishHelp();
void driverHelp();
void dishChoices();
void driverChoices();

#endif